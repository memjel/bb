# Định nghĩa tệp nguồn và tệp đích
file_path = "du_lieu.txt"  # Đường dẫn tệp gốc
output_path = "proxy.txt"  # Đường dẫn tệp mới sau khi chỉnh sửa
chu_them = ":3128"  

# Đọc tệp và chỉnh sửa
with open(file_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

# Ghi lại tệp với nội dung đã chỉnh sửa
with open(output_path, "w", encoding="utf-8") as f:
    for line in lines:
        f.write(line.strip() + chu_them + "\n")

print("Đã thêm chữ vào cuối mỗi dòng và lưu vào:", output_path)