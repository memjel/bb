import json
import requests
import queue
import time
import threading
from concurrent.futures import ThreadPoolExecutor
import os

# Load config
with open("config.json") as f:
    config = json.load(f)

check_site = config["check-site"]
proxy_type = config["proxy-type"]
headers = config["headers"]
print_enabled = config["print_ips"]["enabled"]
display_ip_info = config["print_ips"]["display-ip-info"]
timeout_config = config["timeout"]
timeout = timeout_config.get(f"{proxy_type}_timeout", 8)
max_threads = config["http_threads"]

# === MENU hỏi người dùng nhập file ===
print("===== Proxy Checker Menu =====")
proxy_file = input("📥 Nhập tên file chứa proxy đầu vào (vd: proxy.txt): ").strip()
live_proxy_file = input("📤 Nhập tên file sẽ lưu proxy sống (vd: proxies.txt): ").strip()

# Kiểm tra file đầu vào
if not os.path.exists(proxy_file):
    print(f"❌ File đầu vào '{proxy_file}' không tồn tại!")
    exit(1)

# Kiểm tra file đầu ra
if os.path.exists(live_proxy_file):
    confirm = input(f"⚠️ File đầu ra '{live_proxy_file}' đã tồn tại. Ghi tiếp vào file này? (y/n): ").strip().lower()
    if confirm != "y":
        print("❌ Đã hủy thao tác.")
        exit(0)
else:
    # Nếu file chưa tồn tại → tạo file rỗng
    with open(live_proxy_file, "w") as f:
        pass

# Hàng đợi proxy
proxy_queue = queue.Queue()
working_proxies = []

# Nạp proxy từ file
with open(proxy_file) as f:
    proxies = [line.strip() for line in f if line.strip()]
    total_proxies = len(proxies)
    for proxy in proxies:
        proxy_queue.put(proxy)

# Biến đếm và khóa để đồng bộ chỉ số
counter = 0
lock = threading.Lock()

# Kiểm tra proxy
def check_proxy(proxy, index):
    try:
        proxies = {
            "http": f"{proxy_type}://{proxy}",
            "https": f"{proxy_type}://{proxy}"
        }
        r = requests.get(check_site, headers=headers, proxies=proxies, timeout=timeout)
        if r.status_code == 200:
            if print_enabled:
                print(f"[{index}/{total_proxies}] [LIVE] {proxy}")

            if display_ip_info:
                try:
                    ip = proxy.split(":")[0]
                    info = requests.get(f"http://ip-api.com/json/{ip}").json()
                    country = info.get("country", "Unknown")
                    print(f"   └──> {ip} | {country}")
                except:
                    print(f"   └──> Không lấy được thông tin IP")

            # Ghi vào file live ngay lập tức
            with open(live_proxy_file, "a") as f:
                f.write(proxy + "\n")
            working_proxies.append(proxy)
        else:
            if print_enabled:
                print(f"[{index}/{total_proxies}] [BAD ] {proxy}")
    except:
        if print_enabled:
            print(f"[{index}/{total_proxies}] [FAIL] {proxy}")

# Worker đa luồng
def worker():
    global counter
    while not proxy_queue.empty():
        proxy = proxy_queue.get()
        with lock:
            counter += 1
            index = counter
        check_proxy(proxy, index)
        proxy_queue.task_done()

# Chạy
start_time = time.time()
with ThreadPoolExecutor(max_workers=max_threads) as executor:
    for _ in range(max_threads):
        executor.submit(worker)

proxy_queue.join()
end_time = time.time()

print(f"\n✅ Hoàn thành. Tổng proxy sống: {len(working_proxies)}. Thời gian: {end_time - start_time:.2f} giây.")
print(f"📄 File kết quả: {live_proxy_file}")